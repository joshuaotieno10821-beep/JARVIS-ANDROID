# JARVIS-AI
A futuristic Android assistant prototype with a WebView interface and voice features where supported.

## Build
Open this project in Android Studio, allow Gradle sync, then select **Build > Build APK(s)**.
The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

This is a prototype. Full AI chat and secure external integrations require a backend service.
